var express = require('express');
var router = express.Router();
var users = require('../models/users');
var config = require('../config');

router.post('/create', function (req, res) {
    users.createUser(req.body, function (err, responce) {
        if (err) {
            res.send({ success: false, meaasge: err.sqlMessage });
            return;
        }
        res.send({ success: true, meaasge: 'User Created Successfully' });
    });
});

router.post('/login', function (req, res) {
    users.userLogin(req.body, function (err, responce) {
        if (err){
            res.send({ success: false, meaasge: err });
        }else {
            if(responce.length === 1){
                res.send({ success: true, meaasge: 'User Loged In Successfully', userId: responce[0].userid });
            }else {
                res.send({ success: false, meaasge: 'User Login Err' });
            }
        }
    });
});

module.exports = router;