var express = require('express');
var router = express.Router();
var board = require('../models/board');
var config = require('../config');

router.post('/create', function (req, res) {
    board.createBoard(req.body, function (err, responce) {
        if (err) {
            res.send({ success: false, meaasge: 'Board Createation Fails', error: err });
            return;
        }
        if (Object.keys(responce).length > 0) {
            res.send({ success: true, meaasge: 'Board Created Successfully', boardId: responce.insertId });
        } else {
            res.send({ success: false, meaasge: 'Board Createation Fails' });
        }
    });
});

router.get('/get-board/:userId', function (req, res) {
    board.getBoard(req.params.userId,function(err,responce){
        if(err) {
            res.send({success:false,error:err,message:'Error Occured'});
            return;
        }
        res.send({success:true,data:responce});
    });
});
module.exports = router;