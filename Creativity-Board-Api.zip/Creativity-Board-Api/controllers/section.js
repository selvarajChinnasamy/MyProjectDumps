var express = require('express');
var router = express.Router();
var section = require('../models/section');
var config = require('../config');

router.post('/create', function (req, res) {
    section.createSection(req.body, function (err, responce) {
        if (err) {
            res.send({ success: false, meaasge: 'Section Createation Fails', error: err });
            return;
        }
        if (Object.keys(responce).length > 0) {
            res.send({ success: true, meaasge: 'Section Created Successfully'});
        } else {
            res.send({ success: false, meaasge: 'Section Createation Fails' });
        }
    });
});

router.get('/get-section/:boardId', function (req, res) {
    section.getSection(req.params.boardId,function(err,responce){
        if(err) {
            res.send({success:false,error:err,message:'Error Occured'});
            return;
        }
        res.send({success:true,data:responce});
    });
});
module.exports = router;