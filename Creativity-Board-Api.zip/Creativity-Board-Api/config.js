module.exports = {
	'database': {
		'database': 'creativityboard',
		'url': 'db4free.net',
		'port': 3306,
		'user': 'creativityboard',
		'password': 'creativity-board'
	},
	'port':3002
};