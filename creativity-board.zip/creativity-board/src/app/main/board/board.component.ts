import { Component, OnInit } from '@angular/core';
import { SocketService } from '../socket.service';
import { Event } from '../socket.events';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.css']
})
export class BoardComponent implements OnInit {
  openModel: boolean;
  ioConnection: any;

  constructor(private socketService: SocketService) { }

  ngOnInit() {
    this.initIoConnection();
  }
  private initIoConnection(): void {
    this.socketService.initSocket();

    this.ioConnection = this.socketService.onMessage()
      .subscribe((message: any) => {
        console.log(message);
      });

    this.socketService.onEvent(Event.CONNECT)
      .subscribe(() => {
        console.log('connected');
      });

    this.socketService.onEvent(Event.DISCONNECT)
      .subscribe(() => {
        console.log('disconnected');
      });
  }
  openModelFn() {
    this.openModel = true;
  }
  closeModelFn() {
    this.openModel = false;
  }
}
