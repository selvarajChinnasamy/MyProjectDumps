import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BoardComponent } from './board/board.component';

export const router: Routes = [
  {
    path: '',
    component: BoardComponent
  }
];

export const routes: ModuleWithProviders = RouterModule.forChild(router);
