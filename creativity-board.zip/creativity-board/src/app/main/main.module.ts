import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BoardComponent } from './board/board.component';
import { routes } from './main.router';
import { SocketService } from './socket.service';
@NgModule({
  imports: [
    CommonModule,
    routes
  ],
  declarations: [BoardComponent],
  providers: [SocketService]
})
export class MainModule { }
