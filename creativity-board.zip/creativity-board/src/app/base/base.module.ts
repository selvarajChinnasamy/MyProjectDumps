import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { TosterComponent } from './toster/toster.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NotificationService } from './notification.service';
@NgModule({
  imports: [
    CommonModule,
    SimpleNotificationsModule.forRoot(),
    BrowserAnimationsModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    TosterComponent
  ],
  exports: [
    TosterComponent,
    HeaderComponent,
    FooterComponent
  ],
  providers: [ NotificationService ]
})
export class BaseModule { }
