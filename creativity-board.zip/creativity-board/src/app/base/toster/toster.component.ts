import { Component, OnInit } from '@angular/core';
import { NotificationsService } from 'angular2-notifications';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'app-toster',
  templateUrl: './toster.component.html',
  styleUrls: ['./toster.component.css']
})
export class TosterComponent implements OnInit {

  constructor(private simpleNotificationsModule: NotificationsService, private notificationService: NotificationService) {
    this.notificationService.notifi.subscribe(res => {
      this.notify(res);
    });
   }
  public options = {
    position: ['top', 'right'],
    timeOut: 5000,
    lastOnBottom: true
};
  ngOnInit() {}

  notify(data) {
    this.simpleNotificationsModule.create(
      data.title,
      data.content,
      data.type
  );
  }

}
