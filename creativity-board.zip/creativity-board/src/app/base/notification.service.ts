import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class NotificationService {
  notifi = new BehaviorSubject({});
  createnotification(data) {
    this.notifi.next(data);
  }
}
