import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

export const router: Routes = [
  {
    path: 'board/:id',
    loadChildren: './main/main.module#MainModule'
  },
  {
    path: 'dashboard',
    loadChildren: './common/common.module#CommonModulee'
  }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);
