import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { NotificationService } from '../../base/notification.service';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-create-board',
  templateUrl: './create-board.component.html',
  styleUrls: ['./create-board.component.css']
})
export class CreateBoardComponent implements OnInit {
  color: string;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private notificationService: NotificationService,
    private fb: FormBuilder,
    private commonService: CommonService,
    private formBuilder: FormBuilder) { }

  createForm: FormGroup;
  isSubmitted: boolean;
  ngOnInit() {
    this.buildForm();
  }
  buildForm() {
    this.isSubmitted = false;
    this.createForm = this.fb.group({
      title: ['', [Validators.required]],
      sections: this.formBuilder.array([this.createSectionInputs()])
    });
  }
  createSectionInputs(): FormGroup {
    return this.formBuilder.group({
      color: ['', [Validators.required]],
      title: ['', [Validators.required]],
    });
  }
  get sections(): FormArray {
    return <FormArray>this.createForm.get('sections');
  }
  addSections(): void {
    this.sections.push(this.createSectionInputs());
  }
  createSection() {
    console.log(this.createForm.value);
    // this.commonService.login(this.createForm.value).subscribe(res => {
    //   if (res['success']) {
    //     this.router.navigate(['../create'], { relativeTo: this.route });
    //   } else {
    //     this.notificationService.createnotification({ title: 'Warning', content: res['meaasge'], type: 'alert' });
    //   }
    // });
  }
}
