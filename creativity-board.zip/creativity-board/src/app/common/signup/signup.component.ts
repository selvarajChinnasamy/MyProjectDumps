import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from '../../base/notification.service';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router,
    private notificationService: NotificationService,
    private fb: FormBuilder,
    private commonService: CommonService) { }

  signupForm: FormGroup;
  isSubmitted: boolean;
  ngOnInit() {
    this.buildForm();
  }
  buildForm() {
    this.isSubmitted = false;
    this.signupForm = this.fb.group({
      mailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }
  signup() {
    this.commonService.signup(this.signupForm.value).subscribe(res => {
      if (res['success']) {
        this.router.navigate(['../create'], { relativeTo: this.route });
      } else {
        this.notificationService.createnotification({ title: 'Warning', content: res['meaasge'], type: 'alert' });
      }
    });
  }
}
