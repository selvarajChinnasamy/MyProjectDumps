import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CreateBoardComponent } from './create-board/create-board.component';
import { MainComponent } from './main/main.component';

export const router: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'signup',
        component: SignupComponent
      },
      {
        path: 'create',
        component: CreateBoardComponent
      }
    ]
  }
];

export const routes: ModuleWithProviders = RouterModule.forChild(router);
