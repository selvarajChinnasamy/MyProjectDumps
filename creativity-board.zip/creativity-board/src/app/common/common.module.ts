import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CreateBoardComponent } from './create-board/create-board.component';
import { MainComponent } from './main/main.component';
import { ColorPickerModule } from 'ngx-color-picker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Routs
import { routes } from './common.router';

@NgModule({
  imports: [
    CommonModule,
    routes,
    ColorPickerModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [LoginComponent, SignupComponent, CreateBoardComponent, MainComponent]
})
export class CommonModulee { }
