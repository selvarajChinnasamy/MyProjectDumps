import { Component, OnInit } from '@angular/core';
import { NotificationService } from '../../base/notification.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router,
    private notificationService: NotificationService,
    private fb: FormBuilder,
    private commonService: CommonService) { }

  loginForm: FormGroup;
  isSubmitted: boolean;
  ngOnInit() {
    this.buildForm();
  }
  buildForm() {
    this.isSubmitted = false;
    this.loginForm = this.fb.group({
      mailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }
  login() {
    this.isSubmitted = true;
    if ( this.loginForm.invalid ) { return; }
    this.commonService.login(this.loginForm.value).subscribe(res => {
      if (res['success']) {
        this.router.navigate(['../create'], { relativeTo: this.route });
      } else {
        this.notificationService.createnotification({ title: 'Warning', content: res['meaasge'], type: 'alert' });
      }
    });
  }
}
